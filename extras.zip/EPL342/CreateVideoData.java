import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreateVideoData {

	public static void main(String[] args) throws IOException {
		int up = 8, down = 0; // MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		String privacy[] = {"1", "2", "3", "4"};
		String videoN[] = {"Video1", "Video2", "Video3", "Video4", "Video5",
				"Video6", "Video7", "Video8", "Video9", "Video10", "Video11",
				"Video12", "Video13", "Video14", "Video15"};
		int length = videoN.length;
		
		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\VIDEO.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\VIDEO.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			String str;
			str = br.readLine();
			int c = 1;

			for (int i = 1; i <= 100; i++) {
				int times = (int) ((Math.random() * (up - down)) + down);
				for (int j = 0; j < times; j++) {
					int r = (int)((Math.random() * (4 - 0)) + 0);
					int n = (int)((Math.random() * (length - 0)) + 0);
					int u = (int)((Math.random() * (100 - 1)) + 1);
									
						fw.write(videoN[n] + "\t" + i + "\t" + privacy[r] + "\n");
				

				}
			}
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
