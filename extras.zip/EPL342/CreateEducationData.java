import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreateEducationData {

	public static void main(String[] args) throws IOException {
		int up = 2, down = 0; // MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		String[] array = { "University of Oxford", "California Instutite of Technology", "University of Cabridge",
				"Stanford University", "Massachusetts Institute of Technology", "Princeton University",
				"Harvard University", " Yale University", "The University of Chicago", "Implerial Collage",
				"University of Pensylvania", "Hopkins University", "University of California", "Columbia University",
				"University of Tronto", "University of California", "Cornell University", "Duke University",
				"University of Cyprus", "University of Nicosia", "European University", "TEPAK"};
		int length = array.length;

		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\EDUCATION.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\EDUCATION.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			String str;
			str = br.readLine();

			for (int i = 1; i <= 100; i++) {
				int times = (int) ((Math.random() * (up - down)) + down);
				for (int j = 0; j < times; j++) {
					int r = (int) ((Math.random() * (length - down)) + down);
					fw.write(i + "\t" + array[r] + "\n");

				}
			}
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
