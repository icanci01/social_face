import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;

public class CreateFriendRequestData {

	public static void main(String[] args) throws IOException {
		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {
             
			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\FRIEND_REQUEST.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\FRIEND_REQUEST.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);
			
			
			String str;
			int c = 1;
			str = br.readLine();
			while((str = br.readLine()) != null) {
	              StringBuffer sb = new StringBuffer(str);
	              
	              int pending = 0, ignore = 0;
	              double d = Math.random();
	              if (d > 0.6 && d <= 0.7) { pending = 1; ignore = 0;}
	              else if (d > 0.7 && d <= 0.8) {pending = 0; ignore = 1;}
	              else if (d > 0.8) {pending = ignore = 1;}
	        
	              
	            sb.append("\t" + pending + "\t" + ignore + "\n");
	              c++;
	              bw.write(sb.toString());
	              }

			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
