import java.io.*;
import java.sql.*;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class FeedSql {

	public static void account(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\ACCOUNT.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate("INSERT INTO [dbo].ACCOUNT(username,password)" + "VALUES ('"
						+ split[0] + "','" + split[1] + "')");

				System.out.println("ACCOUNT done.");
			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}

	public static void city(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\CITY.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate("INSERT INTO [dbo].CITY(city)" + "VALUES ('" + split[0] + "')");

				System.out.println("CITY Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}

	public static void location(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\LOCATION.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				byte sn = Byte.parseByte(split[1]);
				short pc = Short.parseShort(split[2]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate("INSERT INTO [dbo].LOCATION(street_name,street_number,postal_code)" + "VALUES ('" + split[0] + "'," + sn + "," + pc + ")");

				System.out.println("LOCATION Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}

	public static void profile(Connection con, String url) throws IOException, ParseException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\PROFILE.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int bit = Integer.parseInt(split[2]);
				int ht = Integer.parseInt(split[3]);
				int l = Integer.parseInt(split[4]);
				int ai = Integer.parseInt(split[7]);
				int v = Integer.parseInt(split[8]);

				String t = split[5];
				String d = "";

				d += (t.substring(6, 10));
				d += "-";
				d += (t.substring(3, 5));
				d += "-";
				d += (t.substring(0, 2));

				java.sql.Date sqlD = java.sql.Date.valueOf(d);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
						"INSERT INTO [dbo].PROFILE(first_name,last_name,gender,hometown,location,birthdate,link,account_id,verified)"
								+ "VALUES ('" + split[0] + "','" + split[1] + "'," + bit + "," + ht + "," + l
								+ ",'" + sqlD + "','" + split[6] + "'," + ai + "," + v + ")");

				System.out.println("PROFILE Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}

	public static void privacy(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\PRIVACY.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
						"INSERT INTO [dbo].PRIVACY(privacy)" + "VALUES ('" + split[0] + "')");

				System.out.println("PRIVACY Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}

	public static void album(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\ALBUM.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[1]);
				byte p = Byte.parseByte(split[3]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
						"INSERT INTO [dbo].ALBUM(name,user_id,link,privacy)" + "VALUES ('" + split[0] + 
						"'," + uid + ",'" + split[2] + "'," + p + ")");

				System.out.println("ALBUM Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void photo(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\PHOTO.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				short height = Short.parseShort(split[2]);
				short width = Short.parseShort(split[3]);
				byte p = Byte.parseByte(split[5]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				if (split.length == 8)
					stmt.executeUpdate(
							"INSERT INTO [dbo].PHOTO(user_id,directory,height,width,link, privacy, album_id)" + "VALUES (" 
					+ uid + ",'" + split[1] + "'," + height + "," + width + ",'" + split[4] + "'," + p + "," + Integer.parseInt(split[6]) + ")");
				else
					stmt.executeUpdate(
							"INSERT INTO [dbo].PHOTO(user_id,directory,height,width,link, privacy)" + "VALUES (" 
					+ uid + ",'" + split[1] + "'," + height + "," + width + ",'" + split[4] + "'," + p + ")");
				
				System.out.println("PHOTO Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}

	public static void video(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\VIDEO.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[1]);
				byte p = Byte.parseByte(split[2]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				if (split.length == 5)
					stmt.executeUpdate(
							"INSERT INTO [dbo].VIDEO(message,user_id,privacy, album_id)" + "VALUES ('" 
					+ split[0] + "'," + uid + "," + p + "," + Integer.parseInt(split[3]) + ")");
				else
					stmt.executeUpdate(
							"INSERT INTO [dbo].VIDEO(message,user_id,privacy)" + "VALUES ('" 
					+ split[0] + "'," + uid + "," + p + ")");
				
				System.out.println("VIDEO Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void bookmark(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\BOOKMARK.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[1]);
				byte p = Byte.parseByte(split[3]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].BOOKMARK(name,user_id,link,privacy)" + "VALUES ('" 
				+ split[0] + "'," + uid + ",'" + split[2] + "'," + p + ")");
				
				System.out.println("BOOKMARK Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void work(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\WORKS.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].WORKS(user_id,work)" + "VALUES (" 
					+ uid + ",'" + split[1] +  "')");
				
				System.out.println("WORKS Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void education(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\EDUCATION.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].EDUCATION(user_id,education)" + "VALUES (" 
					+ uid + ",'" + split[1] +  "')");
				
				System.out.println("EDUCATION Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void website(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\WEBSITE.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].WEBSITE(user_id,website)" + "VALUES (" 
					+ uid + ",'" + split[1] +  "')");
				
				System.out.println("WEBSITE Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void quotes(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\QUOTES.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].QUOTES(user_id,quote)" + "VALUES (" 
					+ uid + ",'" + split[1] +  "')");
				
				System.out.println("QUOTES Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void interest(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\INTEREST.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].INTEREST(interest)" + "VALUES ('" + split[0] +  "')");
				
				System.out.println("INTEREST Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void profile_interest(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\PROFILE_INTEREST.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				int iid = Integer.parseInt(split[1]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].PROFILE_INTEREST(user_id,interest_id)" + "VALUES (" 
					+ uid + "," + iid +  ")");
				
				System.out.println("PROFILE_INTEREST Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void likes(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\LIKE.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				int pid = Integer.parseInt(split[1]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].LIKES(user_id,photo_id)" + "VALUES (" 
					+ uid + "," + pid +  ")");
				
				System.out.println("LIKES Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void friend_request(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\FRIEND_REQUEST.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int u1id = Integer.parseInt(split[0]);
				int u2id = Integer.parseInt(split[1]);
				int p = Integer.parseInt(split[2]);
				int i = Integer.parseInt(split[3]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].FRIEND_REQUEST(user1_id,user2_id,pending,ignore)" + "VALUES (" 
					+ u1id + "," + u2id + "," + p + "," + i +  ")");
				
				System.out.println("FRIEND_REQUEST Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void comment_album(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\ALBUM_COMMENT.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int userid = Integer.parseInt(split[0]);
				int album = Integer.parseInt(split[2]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].COMMENT_ALBUM(user_id,comment,album_id)" + "VALUES (" 
					+ userid + ",'" + split[1] + "'," + album +  ")");
				
				System.out.println("COMMENT_ALBUM Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void comment_video(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\COMMENT_VIDEO.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int userid = Integer.parseInt(split[0]);
				int video = Integer.parseInt(split[2]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].COMMENT_VIDEO(user_id,comment,video_id)" + "VALUES (" 
					+ userid + ",'" + split[1] + "'," + video +  ")");
				
				System.out.println("COMMENT_VIDEO Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}

	public static void event(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\EVENT.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int owner = Integer.parseInt(split[1]);
				int loca = Integer.parseInt(split[4]);
				int city = Integer.parseInt(split[5]);
				byte p = Byte.parseByte(split[6]);
				
				
				
				java.sql.Timestamp start = java.sql.Timestamp.valueOf(split[2]);
				java.sql.Timestamp end = java.sql.Timestamp.valueOf(split[3]);
				
				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].EVENT(name,owner,start_time,end_time,location,venue,privacy)" + "VALUES ('" 
				+ split[0] + "'," + owner + ",'" + start + "','" + end + "'," + loca + "," + city +  
					"," + p + ")");
				
				System.out.println("EVENT Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	
	public static void participates(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\PARTICIPATES.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				int pid = Integer.parseInt(split[1]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].PARTICIPANTS(user_id,event_id)" + "VALUES (" 
					+ uid + "," + pid +  ")");
				
				System.out.println("PARTICIPATES Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void album_photo(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\ALBUM_PHOTO.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				int pid = Integer.parseInt(split[1]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].ALBUM_PHOTO(album_id,photo_id)" + "VALUES (" 
					+ uid + "," + pid +  ")");
				
				System.out.println("ALBUM PHOTO Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	public static void album_video(Connection con, String url) throws IOException {

		BufferedReader objReader = new BufferedReader(new FileReader("C:\\EPL342_FEED_DATABASE\\ALBUM_VIDEO.txt"));
		String strCurrentLine = objReader.readLine();

		while ((strCurrentLine = objReader.readLine()) != null) {
			try {
				String[] split = strCurrentLine.split("\t");

				int uid = Integer.parseInt(split[0]);
				int pid = Integer.parseInt(split[1]);

				Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.executeUpdate(
							"INSERT INTO [dbo].ALBUM_VIDEO(album_id,video_id)" + "VALUES (" 
					+ uid + "," + pid +  ")");
				
				System.out.println("ALBUM VIDEO Done");

			} catch (SQLException e1) {
				System.out.println("Query Failed");
			}
		}

	}
	
	
	public static void main(String[] args) throws IOException, ParseException {

		String url = "jdbc:sqlserver://APOLLO.IN.CS.UCY.AC.CY:1433;databaseName=gproko01;user=gproko01;password=3cp2e7UW;";

		Connection con = null;

		try {
			con = DriverManager.getConnection(url);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		account(con, url);
		city(con, url);
		location(con,url);
		privacy(con,url);
		profile(con, url);
		album(con, url);
		photo(con, url);
		video(con, url);
		quotes(con, url);
		website(con, url);
		work(con, url);
		education(con, url);
		interest(con, url);
		profile_interest(con, url);
		likes(con, url);
		friend_request(con, url);
		bookmark(con, url);
		comment_album(con,url);
		comment_video(con, url);
		event(con, url);
		participates(con, url);
		album_video(con, url);
		album_photo(con, url);
	}
}