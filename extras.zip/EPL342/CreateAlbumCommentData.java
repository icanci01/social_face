import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreateAlbumCommentData {

	public static void main(String[] args) throws IOException {
		int up = 8, down = 0; // MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		String privacy[] = {"00", "01", "10", "11"};
		String comment[] = {"Comment1", "Comment2", "Comment3", "Comment4", "Comment5",
				"Comment6", "Comment7", "Comment8", "Comment9", "Comment10", "Comment11",
				"Comment12", "Comment13", "Comment14", "Comment15"};
		int length = comment.length;
		
		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\ALBUM_COMMENT.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\ALBUM_COMMENT.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			String str;
			str = br.readLine();
			int c = 1;

			for (int i = 1; i <= 100; i++) {
				int times = (int) ((Math.random() * (up - down)) + down);
				for (int j = 0; j < times; j++) {
					int r = (int)((Math.random() * (244 - 1)) + 1);
					int n = (int)((Math.random() * (length - 0)) + 0);
				
					fw.write(i + "\t" + comment[n]  + "\t" + r + "\n");
					c++;
				}
			}
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}