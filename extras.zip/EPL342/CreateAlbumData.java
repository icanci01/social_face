import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreateAlbumData {

	public static void main(String[] args) throws IOException {
		int up = 6, down = 0; // MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		String privacy[] = {"1", "2", "3", "4"};
		String albumN[] = {"Album1", "Album2", "Album3", "Album4", "Album5",
				"Album6", "Album7", "Album8", "Album9", "Album10", "Album11",
				"Album12", "Album13", "Album14", "Album15"};
		int length = albumN.length;

		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\ALBUM.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\ALBUM.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			String str;
			str = br.readLine();
			int c = 1;

			for (int i = 1; i <= 100; i++) {
				int times = (int) ((Math.random() * (up - down)) + down);
				for (int j = 0; j < times; j++) {
					int r = (int)((Math.random() * (4 - 0)) + 0);
					int n = (int)((Math.random() * (length - 0)) + 0);
					fw.write(albumN[n] + "\t" + i + "\twww.album" + c + ".com\t" + privacy[r] + "\n");
					c++;
				}
			}
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
