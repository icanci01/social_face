import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;
import java.sql.*;


public class Login extends JFrame implements ActionListener {
    JPanel panel;
    JLabel user_label, password_label, message;
    JTextField userName_text;
    JPasswordField password_text;
    JButton submit, cancel;

    Login() {
        // Username Label
        user_label = new JLabel();
        user_label.setText("User Name :");
        userName_text = new JTextField();
        // Password Label
        password_label = new JLabel();
        password_label.setText("Password :");
        password_text = new JPasswordField();
        // Submit
        submit = new JButton("SUBMIT");
        panel = new JPanel(new GridLayout(3, 1));
        panel.add(user_label);
        panel.add(userName_text);
        panel.add(password_label);
        panel.add(password_text);
        message = new JLabel();
        panel.add(message);
        panel.add(submit);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Adding the listeners to components..
        submit.addActionListener(this);
        add(panel, BorderLayout.CENTER);
        setTitle("Social Life - Login");
        setSize(450, 350);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Login();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        String userName = userName_text.getText();
        String password = password_text.getText();
        System.out.printf("%s%s", userName, password);
        Vector storeProcINParams = new Vector();
        storeProcINParams.add(userName);
        storeProcINParams.add(password);
        String storProcName = "upsLogin";
        Boolean getOUTParameter = false;
        try {
            JDBC anObj = new JDBC();
            Connection conn = anObj.getDBConnection();
            ResultSet r = anObj.executeStoreProc(storProcName, storeProcINParams, getOUTParameter);
            System.out.printf("%s", r == null);
            while (r.next()) {
                int id = r.getInt("id");
                System.out.print(id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}