import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;

public class CreateProfileData {

	public static void main(String[] args) throws IOException {
		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {
             
			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\PROFILE.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\PROFILE.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);
			
			
			String str;
			int c = 1;
			str = br.readLine();
			while((str = br.readLine()) != null) {
	              StringBuffer sb = new StringBuffer(str);
	              
	              int verified = 1;
	              if (Math.random() > 0.8) verified = 0;
	              
	            sb.append("\twww.profile" + c + ".com\t" + c + "\t" + verified + "\n");
	              c++;
	              bw.write(sb.toString());
	              }

			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
