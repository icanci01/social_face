import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreateAccountData {

	public static void main(String[] args) throws IOException {
		int up = 5, down = 0; // MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		String[] array = { "angel", "bubbles", "shimmer", "angelic", "bubbly", "glimmer", "baby", "pink", "little",
				"butterfly", "sparkly", "doll", "sweet", "sparkles", "dolly", "sweetie", "sprinkles", "lolly",
				"princess", "fairy", "honey", "snowflake", "pretty", "sugar", "cherub", "lovely", "blossom",
				"sugardaddy", "Bandalls", "Wattlexp", "Sweetiele", "HyperYauFarer", "Editussion", "Experthead",
				"Flamesbria", "HeroAnhart", "Liveltekah", "Linguss", "Interestec", "FuzzySpuffy", "Monsterup",
				"MilkA1Baby", "LovesBoost", "Edgymnerch", "Ortspoon", "Oranolio", "OneMama", "Dravenfact", "Reallychel",
				"Reakefit", "Popularkiya", "Breacche", "Blikimore", "StoneWellForever", "Simmson", "BrightHulk",
				"Bootecia", "Spuffyffet", "Rozalthiric", "Bookman", "noopas", "ImortalHanshi", "uffaw", "hitherto",
				"ligature", "guidon", "hoary", "limner", "guilloche", "hobbledehoy", "titmouse", "holystone",
				"hobgoblin", "tittup", "homeric", "intagliated", "tmesis", "tormentil", "Ecophobia", "Hippophobia",
				"Scolionophobia", "Ergophobia", "Musophobia", "Zemmiphobia", "Geliophobia", "Tachophobia", "Hadephobia",
				"Radiophobia", "Terrorist", "Warzone", "Tripaloski", "Pollos", "Hermanos", "Benjamin", "Ruski", "Peace",
				"Love", "Etho", "Nickmerks", "ImExpel", "Scubbi", "Velma", "Panther", "Tiger" };

		String[] array1 = { "123456", "123456789", "picture1", "password", "1111111", "123123", "abc123", "iloveyou",
				"aaron431", "qqww1122", "omgpop", "asdfghjkl", "qwerty", "admin", "sunshine", "ashley", "football",
				"starwars_12", "passw0rd", "!@#$%^" };

		int length1 = array1.length;

		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\ACCOUNT.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\ACCOUNT.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			for (int i = 1; i <= 100; i++) {
				int r = (int) ((Math.random() * (length1 - 0)) + 0);
				fw.write(array[i] + "\t" + array1[r] + "\n");

			}
			
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
