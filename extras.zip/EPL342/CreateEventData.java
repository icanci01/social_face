import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreateEventData {

	public static void main(String[] args) throws IOException {
		int up = 3, down = 0; // MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		String privacy[] = {"1", "2", "3", "4"};
		String EventN[] = {"Event1", "Event2", "Event3", "Event4", "Event5",
				"Event6", "Event7", "Event8", "Event9", "Event10", "Event11",
				"Event12", "Event13", "Event14", "Event15"};
		int length = EventN.length;
		
		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\EVENT.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\EVENT.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			String str;
			str = br.readLine();
			int c = 1;

			for (int i = 1; i <= 100; i++) {
				int times = (int) ((Math.random() * (up - down)) + down);
				for (int j = 0; j < times; j++) {
					int MM = (int)((Math.random() * (11 - 10)) + 10);
					int DD = (int)((Math.random() * (30 - 10)) + 10);
					int hh = (int)((Math.random() * (23 - 10)) + 10);
					int mm = (int)((Math.random() * (59 - 10)) + 10);
					int ss = (int)((Math.random() * (59 - 10)) + 10);
					int p = (int)((Math.random() * (4 - 0)) + 0);
					int location = (int)((Math.random() * (20 - 1)) + 1);
					int city = (int)((Math.random() * (707 - 1)) + 1);
					int n = (int)((Math.random() * (length - 0)) + 0);
					
					

					
					fw.write(EventN[n] + "\t" + i + "\t2020-" + MM + "-" + DD + " " + hh + ":" + mm + ":" + ss + "\t" +
							"2020-" + MM + "-" + DD + " " + (hh+1) + ":" + mm + ":" + ss + "\t" + + location + "\t" + city + "\t" + privacy[p] + "\n");
					c++;
				}
			}
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
