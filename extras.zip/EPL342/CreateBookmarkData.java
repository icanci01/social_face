import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreateBookmarkData {

	public static void main(String[] args) throws IOException {
		int up = 5, down = 0; // MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		String bookmarkN[] = {"Bookmark1", "Bookmark2", "Bookmark3", "Bookmark4", "Bookmark5",
				"Bookmark6", "Bookmark7", "Bookmark8", "Bookmark9", "Bookmark10", "Bookmark11",
				"Bookmark12", "Bookmark13", "Bookmark14", "Bookmark15"};
		int length = bookmarkN.length;
		String privacy[] = {"1", "2", "3", "4"};
		
		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\BOOKMARK.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\BOOKMARK.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			String str;
			str = br.readLine();
			int c = 1;

			for (int i = 1; i <= 100; i++) {
				int times = (int) ((Math.random() * (up - down)) + down);
				for (int j = 0; j < times; j++) {
					int r = (int) ((Math.random() * (length - 0)) + 0);
					int p = (int) ((Math.random() * (4 - 0)) + 0);
					fw.write(bookmarkN[r] + "\t" + i + "\twww.bookmark" + c + ".com\t" + privacy[p] + "\n");
					c++;
				}
			}
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
