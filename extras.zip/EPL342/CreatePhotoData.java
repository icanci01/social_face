import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreatePhotoData {

	public static void main(String[] args) throws IOException {
		int up = 12, down = 0; // MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		int array[][] = {{144,240}, {240,360}, {360,480},{480,720},{720,1080},
						{1080,1920}, {1920,2144}};
		String privacy[] = {"1", "2", "3", "4"};
		int length = array.length;
		
		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\PHOTO.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\PHOTO.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			String str;
			str = br.readLine();
			int c = 1;

			for (int i = 1; i <= 100; i++) {
				int times = (int) ((Math.random() * (up - down)) + down);
				for (int j = 0; j < times; j++) {
					int size = (int)((Math.random() * (length - 0)) + 0);
					int r = (int)((Math.random() * (4 - 0)) + 0);
					int a = (int)((Math.random() * (243 - 1)) + 1);
				
					if (Math.random() > 0.5)
					fw.write(i + "\tC:\\User" + i + ":\\Photo" + c + "\t" +
							array[size][0] + "\t" + array[size][1] +
							"\twww.photo" + c + ".com\t" + privacy[r] + "\n");
					else
						fw.write(i + "\tC:\\User" + i + ":\\Photo" + c + "\t" +
								array[size][0] + "\t" + array[size][1] +
								"\twww.photo" + c + ".com\t" + privacy[r] + "\t" + a + "\n");
					c++;
				}
			}
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
