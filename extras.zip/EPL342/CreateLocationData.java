import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreateLocationData {

	public static void main(String[] args) throws IOException {
		int up = 5, down = 0; // MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		String[] array = {"Abbey Road", "Abbots Road", "Acton Street", "Albert Road", "Alfred Place",
				"Alpha Place", "Approach Road", "OldTown Road", "Basing Road", "Bakers Street",
				"Camden Street", "P. Sherman Walabi", "Church Row", "Devonshire Terrace"};

		int length = array.length;

		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\LOCATION.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\LOCATION.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			String str;
			str = br.readLine();

			for (int i = 1; i <= 100; i++) {
				StringBuffer sb = new StringBuffer(str);
				int pos = (int) ((Math.random() * (length - 0)) + 0);
				int street = (int) ((Math.random() * (12 - 3)) + 3);
				int postal = (int) ((Math.random() * (2890 - 2001)) + 2001);
				fw.write(array[pos] + "\t" + street +  "\t" + postal + "\n");

			}
			
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
