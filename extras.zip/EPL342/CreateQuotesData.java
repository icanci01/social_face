import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle errors
import java.io.PrintWriter;
import java.util.Random;

public class CreateQuotesData {

	public static void main(String[] args) throws IOException {
		int up = 5, down = 0;	// MAX AND MIN NUMBER OF POSSIBLE APPEARANCES
		String[] array = {"You can do anything, but not everything.",
							"You miss 100 percent of the shots you never take.",
							"You must be the change you wish to see in the world.",
							"Love For All, Hatred For None.",
							"Change the world by being yourself.",
							"Every moment is a fresh beginning.",
							"Never regret anything that made you smile.",
							"Die with memories, not dreams.",
							"Aspire to inspire before we expire.",
							"Everything you can imagine is real.",
							"Whatever you do, do it well.",
							"What we think, we become.",
							"All limitations are self-imposed.",
							"Tough times never last but tough people do.",
							"Problems are not stop signs, they are guidelines.",
							"f I�m gonna tell a real story, I�m gonna start with my name.",
							"I don�t need it to be easy, I need it to be worth it.",
							"Never let your emotions overpower your intelligence.",
							"To live will be an awfully big adventure.",
							"Try to be a rainbow in someone�s cloud.",};
		int length = array.length;
		
		FileWriter fw = null;
		FileReader fr = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		try {

			fw = new FileWriter("C:\\EPL342_FEED_DATABASE\\QUOTES.txt", true);
			fr = new FileReader("C:\\EPL342_FEED_DATABASE\\QUOTES.txt");
			bw = new BufferedWriter(fw);
			br = new BufferedReader(fr);
			pw = new PrintWriter(bw);

			String str;
			str = br.readLine();

			for (int i = 1; i <= 100; i++) {
				StringBuffer sb = new StringBuffer(str);
				int times = (int) ((Math.random() * (up - down)) + down);
				for (int j = 0; j < times; j++) {
					int r = (int)((Math.random() * (length - down)) + down);
					fw.write(i + "\t" + array[r] + "\n");
					
					
				}
			}
			System.out.println("Data Successfully appended into file");
			pw.flush();

		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
				br.close();
			} catch (IOException io) {// can't do anything }
			}

		}
	}

}
